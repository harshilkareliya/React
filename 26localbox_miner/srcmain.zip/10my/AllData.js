export const data1 = [
    {
      id: 6,
      userName: "City Light",
      title: "amazing city",
      description:
        "City is everything that provide everything that we need, city is over first monterh 77",
      pImg: "https://cdn.pixabay.com/photo/2023/04/11/16/11/ocean-7917678_640.jpg",
      mImg: "https://cdn.pixabay.com/photo/2016/11/21/16/36/cologne-cathedral-1846338_640.jpg",
      like: 10.3,
      comment: 4.2,
      share: 8.1,
    },
    {
      id: 1,
      userName: "Nature Beauty",
      title: "Nature is awesome",
      description:
        "Nature is everything that provide everything that we need, nature is over first monterh 77",
      pImg: "https://cdn.pixabay.com/photo/2024/01/05/14/00/ship-8489583_1280.jpg",
      mImg: "https://cdn.pixabay.com/photo/2022/10/07/09/06/bridge-7504605_640.jpg",
      like: 2.3,
      comment: 3.2,
      share: 2.1,
    },
    {
      id: 2,
      userName: "Mountaine Hill",
      title: "Mountain",
      description:
        "Nature is everything that provide everything that we need, nature is over first monterh 77",
      pImg: "https://cdn.pixabay.com/photo/2023/03/31/13/37/blue-phacelia-7890014_640.jpg",
      mImg: "https://cdn.pixabay.com/photo/2018/11/19/15/06/machang-bridge-3825439_640.jpg",
      like: 1.3,
      comment: 2.2,
      share: 0.1,
    },
    {
      id: 3,
      userName: "Ocean Beauty",
      title: "ocean is awesome",
      description:
        "Ocean is everything that provide everything that we need, nature is over first monterh 77",
      pImg: "https://cdn.pixabay.com/photo/2024/01/05/14/00/ship-8489583_1280.jpg",
      mImg: "https://cdn.pixabay.com/photo/2019/09/15/14/35/city-4478471_640.jpg",
      like: 1.3,
      comment: 2.2,
      share: 3.1,
    },
    {
      id: 4,
      userName: "Wonderfull Ocean",
      title: "ocean is amazing",
      description:
        "Ocean is everything that provide everything that we need, ocean is over first monterh 77",
      pImg: "https://cdn.pixabay.com/photo/2023/11/12/13/24/tide-8382992_640.jpg",
      mImg: "https://cdn.pixabay.com/photo/2022/12/25/22/09/northern-lights-7677986_640.jpg",
      like: 1.3,
      comment: 2.2,
      share: 1.0,
    },
    {
      id: 5,
      userName: "Hill Beauty",
      title: "Hill is awesome",
      description:
        "Hill is everything that provide everything that we need, Hill is over first monterh 77",
      pImg: "https://cdn.pixabay.com/photo/2023/09/22/10/20/mountains-8268760_640.jpg",
      mImg: "https://cdn.pixabay.com/photo/2023/08/03/14/14/night-8167272_640.jpg",
      like: 8.3,
      comment: 3.2,
      share: 2.1,
    },
  ];


  export const data2 = [
    {
        id: 1,
        img: "https://cdn.pixabay.com/photo/2016/11/13/12/52/kuala-lumpur-1820944_640.jpg",
        authorImg:
            "https://cdn.pixabay.com/photo/2023/01/15/22/48/lake-7721285_640.jpg",
        authorName: "Turkey City",
        authortext: "City of light",
    },
    {
        id: 2,
        img: "https://cdn.pixabay.com/photo/2016/04/01/00/08/toronto-1298016_640.jpg",
        authorImg:
            "https://cdn.pixabay.com/photo/2022/09/16/15/53/city-7458934_640.jpg",
        authorName: "Night City",
        authortext: "City of joy",
    },
    {
        id: 3,
        img: "https://cdn.pixabay.com/photo/2016/10/24/22/43/dubai-1767540_640.jpg",
        authorImg:
            "https://cdn.pixabay.com/photo/2015/02/24/13/23/buildings-647400_640.jpg",
        authorName: "CitySpace",
        authortext: "amazing city",
    },
    {
        id: 4,
        img: "https://cdn.pixabay.com/photo/2016/11/21/16/36/cologne-cathedral-1846338_640.jpg",
        authorImg:
            "https://cdn.pixabay.com/photo/2020/01/25/19/14/paris-4793200_640.jpg",
        authorName: "London City",
        authortext: "city of naute",
    },
    {
        id: 5,
        img: "https://cdn.pixabay.com/photo/2019/04/04/17/58/road-4103334_640.jpg",
        authorImg:
            "https://cdn.pixabay.com/photo/2019/07/21/19/53/skyline-4353504_640.jpg",
        authorName: "Road Show",
        authortext: "road img",
    },
];