import React from 'react';
import img1 from "./img1.jpg";

function About() {
  return (
    <div className='about'>
      <div className='subabout'>
      <div class="about1"><img src={img1} alt=""></img></div>
      <div class="about2 ">
                <br></br>
                <h1>
                    About Conference</h1> <br></br><br></br>
                <p>When I first got into the online advertising business, I was looking for the magical combination that would put my website into the top search engine rankings, catapult me to the forefront of the minds or individuals looking to buy my product, and generally make me rich beyond my wildest dreams! After succeeding in the business for this long, I’m able to look back on my old self with this kind of thinking and shake my head.</p>

            </div>
      </div>
    </div>
  )
}

export default About
