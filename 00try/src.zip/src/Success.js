import React from 'react'

function Success() {
  return (
    <div className="success">
        <h1>Our Successful Persons</h1>
        <div className="subsuc">
            <div className="suc1"> 
                <div className="suc1a">
                    
                </div>
            </div>
            <div className="suc2"> 
                <div className="suc2a">
                  
                </div>
            </div>
            <div className="suc3"> 
                <div className="suc3a">
                  
                </div>
            </div>
            <div className="suc4"> 
                <div className="suc4a">
                  
                </div>
            </div>
        </div>

    </div>
  )
}

export default Success
