import React from 'react'

function Person() {
  return (
    <div>
        <div className="person">

<div className="who">
        <h1>Who’s speaking</h1><br></br>
        <h3>These are our communicators, you can see each person information</h3>
</div>
<div className="photos">
    <div className="photos1">
        <div className="photos1a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos1b">
            <h1>Emma Sandoval</h1>
            <h2>Speaker</h2>
        </div>
    </div>
    <div className="photos2">
        <div className="photos2a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos2b">
            <h1>Emma Sandoval</h1>
            <h2>Speaker</h2>
        </div>
    </div>
    <div className="photos3">
        <div className="photos3a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos3b">
           <h1>Emma Sandoval</h1>
            <h2>Speaker</h2> 
        </div>
    </div>
    <div className="photos4">
        <div className="photos4a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos4b">
           <h1>Emma Sandoval</h1>
            <h2>Speaker</h2> 
        </div>
    </div>
    <div className="photos5">
        <div className="photos5a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos5b">
           <h1>Emma Sandoval</h1>
            <h2>Speaker</h2> 
        </div>
    </div>
    <div className="photos6">
        <div className="photos6a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos6b">
           <h1>Emma Sandoval</h1>
            <h2>Speaker</h2> 
        </div>
    </div>
    <div className="photos7">
        <div className="photos7a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos7b">
           <h1>Emma Sandoval</h1>
            <h2>Speaker</h2> 
        </div>
    </div>
    <div className="photos8">
        <div className="photos8a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos8b">
           <h1>Emma Sandoval</h1>
            <h2>Speaker</h2> 
        </div>
    </div>
    <div className="photos9">
        <div className="photos9a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos9b">
          <h1>Emma Sandoval</h1>
            <h2>Speaker</h2>  
        </div>
    </div>
    <div className="photos10">
        <div className="photos10a">
            <i className="ri-facebook-circle-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-instagram-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-twitter-fill"></i>&nbsp;&nbsp;&nbsp;<i className="ri-linkedin-fill"></i>
        </div>
        <div className="photos10b">
           <h1>Emma Sandoval</h1>
            <h2>Speaker</h2> 
        </div>
    </div>

</div>

</div>
<div class="extra">
</div>
    </div>
  )
}

export default Person
