import './App.css';
import EventCondition from './EventCondition';

function App() {
  return (
    <div className="App">
      <EventCondition/>
    </div>
  );
}

export default App;

