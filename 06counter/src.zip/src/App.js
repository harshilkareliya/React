import logo from './logo.svg';
import './App.css';
import Counter from './Counter';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";

function App() {
  return (
    
    <Counter  />
  );
}

export default App;
