import logo from './logo.svg';
import './App.css';
import Count from './Count';



function App() {
  return (
    <div className="App">
      <Count/>
    </div>
  );
}

export default App;
