import React from 'react';
import './App.css';
import Fetchdata from './Fetchdata';

function App() {
  return (
    <div>
      <Fetchdata/>

    </div>
  );
}

export default App;
